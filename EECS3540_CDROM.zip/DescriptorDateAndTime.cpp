#include "DescriptorDateAndTime.h"

DescriptorDateAndTime::DescriptorDateAndTime()
{
	//ctor
}

DescriptorDateAndTime::~DescriptorDateAndTime()
{
	//dtor
}

DescriptorDateAndTime::DescriptorDateAndTime(unsigned char buffer[17]) {

}
