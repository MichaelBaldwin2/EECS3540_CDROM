#pragma once

int GetEndian();
